package main

import "fmt"

func main() {
	var i int
	i = 100
	fmt.Println(i)
	var bol bool
	bol = true
	fmt.Println(bol)
	var n string = "hello world"
	fmt.Println(n)
}
